#ifndef INTERFACE_H
#define INTERFACE_H

#include "builder.h"
#include "colorpicker.h"

// Handles builder interface visualization

#endif
