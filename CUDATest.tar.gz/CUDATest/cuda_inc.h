#ifndef CUDA_INC_H
#define CUDA_INC_H

#include <cuda.h>
#include <cuda_runtime.h>
#include <device_launch_parameters.h>
//#define NULL NULL

#endif
